--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
ALTER TABLE ONLY public.tb_admin DROP CONSTRAINT tb_admin_pkey;
ALTER TABLE ONLY public.tarif DROP CONSTRAINT tarif_pkey;
ALTER TABLE ONLY public.tagihan DROP CONSTRAINT tagihan_pkey;
ALTER TABLE ONLY public.penggunaan DROP CONSTRAINT penggunaan_pkey;
ALTER TABLE ONLY public.pembayaran DROP CONSTRAINT pembayaran_pkey;
ALTER TABLE ONLY public.pelanggan DROP CONSTRAINT pelanggan_pkey;
ALTER TABLE public.tb_level ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.tb_admin ALTER COLUMN id_admin DROP DEFAULT;
ALTER TABLE public.tarif ALTER COLUMN id_tarif DROP DEFAULT;
ALTER TABLE public.tagihan ALTER COLUMN id_pelanggan DROP DEFAULT;
ALTER TABLE public.tagihan ALTER COLUMN id_pengunaan DROP DEFAULT;
ALTER TABLE public.tagihan ALTER COLUMN id_tagihan DROP DEFAULT;
ALTER TABLE public.penggunaan ALTER COLUMN id_penggunaan DROP DEFAULT;
ALTER TABLE public.pembayaran ALTER COLUMN id_pelanggan DROP DEFAULT;
ALTER TABLE public.pembayaran ALTER COLUMN id_tagihan DROP DEFAULT;
ALTER TABLE public.pembayaran ALTER COLUMN id_pembayaran DROP DEFAULT;
ALTER TABLE public.pelanggan ALTER COLUMN id_pelanggan DROP DEFAULT;
DROP SEQUENCE public.tb_level_id_level_seq;
DROP TABLE public.tb_level;
DROP SEQUENCE public.tb_admin_id_admin_seq;
DROP TABLE public.tb_admin;
DROP SEQUENCE public.tarif_id_tarif_seq;
DROP TABLE public.tarif;
DROP SEQUENCE public.tagihan_id_tagihan_seq;
DROP SEQUENCE public.tagihan_id_pengunaan_seq;
DROP SEQUENCE public.tagihan_id_pelanggan_seq;
DROP TABLE public.tagihan;
DROP SEQUENCE public.penggunaan_id_penggunaan_seq;
DROP TABLE public.penggunaan;
DROP SEQUENCE public.pembayaran_id_tagihan_seq;
DROP SEQUENCE public.pembayaran_id_pembayaran_seq;
DROP SEQUENCE public.pembayaran_id_pelanggan_seq;
DROP TABLE public.pembayaran;
DROP SEQUENCE public.pelanggan_id_pelanggan_seq;
DROP TABLE public.pelanggan;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: pelanggan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pelanggan (
    id_pelanggan integer NOT NULL,
    username character varying(50),
    password character varying(50),
    nomor_kwh integer,
    nama_pelanggan character varying(50),
    alamat text,
    id_tarif integer
);


ALTER TABLE pelanggan OWNER TO postgres;

--
-- Name: pelanggan_id_pelanggan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pelanggan_id_pelanggan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pelanggan_id_pelanggan_seq OWNER TO postgres;

--
-- Name: pelanggan_id_pelanggan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE pelanggan_id_pelanggan_seq OWNED BY pelanggan.id_pelanggan;


--
-- Name: pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pembayaran (
    id_pembayaran integer NOT NULL,
    id_tagihan integer NOT NULL,
    id_pelanggan integer NOT NULL,
    tanggal_pembayaran date,
    bulan_bayar date,
    biaya_admin integer,
    total_bayar integer,
    id_admin integer
);


ALTER TABLE pembayaran OWNER TO postgres;

--
-- Name: pembayaran_id_pelanggan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pembayaran_id_pelanggan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pembayaran_id_pelanggan_seq OWNER TO postgres;

--
-- Name: pembayaran_id_pelanggan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE pembayaran_id_pelanggan_seq OWNED BY pembayaran.id_pelanggan;


--
-- Name: pembayaran_id_pembayaran_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pembayaran_id_pembayaran_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pembayaran_id_pembayaran_seq OWNER TO postgres;

--
-- Name: pembayaran_id_pembayaran_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE pembayaran_id_pembayaran_seq OWNED BY pembayaran.id_pembayaran;


--
-- Name: pembayaran_id_tagihan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pembayaran_id_tagihan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pembayaran_id_tagihan_seq OWNER TO postgres;

--
-- Name: pembayaran_id_tagihan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE pembayaran_id_tagihan_seq OWNED BY pembayaran.id_tagihan;


--
-- Name: penggunaan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE penggunaan (
    id_penggunaan integer NOT NULL,
    id_pelanggan integer,
    bulan date,
    tahun date,
    meter_awal integer,
    meter_akhir integer
);


ALTER TABLE penggunaan OWNER TO postgres;

--
-- Name: penggunaan_id_penggunaan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE penggunaan_id_penggunaan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE penggunaan_id_penggunaan_seq OWNER TO postgres;

--
-- Name: penggunaan_id_penggunaan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE penggunaan_id_penggunaan_seq OWNED BY penggunaan.id_penggunaan;


--
-- Name: tagihan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tagihan (
    id_tagihan integer NOT NULL,
    id_pengunaan integer NOT NULL,
    id_pelanggan integer NOT NULL,
    bulan date,
    tahun date,
    jumlah_meter integer,
    status character varying
);


ALTER TABLE tagihan OWNER TO postgres;

--
-- Name: tagihan_id_pelanggan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tagihan_id_pelanggan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tagihan_id_pelanggan_seq OWNER TO postgres;

--
-- Name: tagihan_id_pelanggan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tagihan_id_pelanggan_seq OWNED BY tagihan.id_pelanggan;


--
-- Name: tagihan_id_pengunaan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tagihan_id_pengunaan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tagihan_id_pengunaan_seq OWNER TO postgres;

--
-- Name: tagihan_id_pengunaan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tagihan_id_pengunaan_seq OWNED BY tagihan.id_pengunaan;


--
-- Name: tagihan_id_tagihan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tagihan_id_tagihan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tagihan_id_tagihan_seq OWNER TO postgres;

--
-- Name: tagihan_id_tagihan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tagihan_id_tagihan_seq OWNED BY tagihan.id_tagihan;


--
-- Name: tarif; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tarif (
    id_tarif integer NOT NULL,
    daya character varying(50),
    tarif_perkwh integer
);


ALTER TABLE tarif OWNER TO postgres;

--
-- Name: tarif_id_tarif_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tarif_id_tarif_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tarif_id_tarif_seq OWNER TO postgres;

--
-- Name: tarif_id_tarif_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tarif_id_tarif_seq OWNED BY tarif.id_tarif;


--
-- Name: tb_admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_admin (
    id_admin integer NOT NULL,
    username character varying(50),
    password character varying(50),
    nama_admin character varying(50),
    id_level integer
);


ALTER TABLE tb_admin OWNER TO postgres;

--
-- Name: tb_admin_id_admin_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_admin_id_admin_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_admin_id_admin_seq OWNER TO postgres;

--
-- Name: tb_admin_id_admin_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_admin_id_admin_seq OWNED BY tb_admin.id_admin;


--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level integer NOT NULL,
    nama_level character varying(50)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_level_id_level_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_level_id_level_seq OWNER TO postgres;

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_level_id_level_seq OWNED BY tb_level.id_level;


--
-- Name: pelanggan id_pelanggan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pelanggan ALTER COLUMN id_pelanggan SET DEFAULT nextval('pelanggan_id_pelanggan_seq'::regclass);


--
-- Name: pembayaran id_pembayaran; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran ALTER COLUMN id_pembayaran SET DEFAULT nextval('pembayaran_id_pembayaran_seq'::regclass);


--
-- Name: pembayaran id_tagihan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran ALTER COLUMN id_tagihan SET DEFAULT nextval('pembayaran_id_tagihan_seq'::regclass);


--
-- Name: pembayaran id_pelanggan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran ALTER COLUMN id_pelanggan SET DEFAULT nextval('pembayaran_id_pelanggan_seq'::regclass);


--
-- Name: penggunaan id_penggunaan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY penggunaan ALTER COLUMN id_penggunaan SET DEFAULT nextval('penggunaan_id_penggunaan_seq'::regclass);


--
-- Name: tagihan id_tagihan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tagihan ALTER COLUMN id_tagihan SET DEFAULT nextval('tagihan_id_tagihan_seq'::regclass);


--
-- Name: tagihan id_pengunaan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tagihan ALTER COLUMN id_pengunaan SET DEFAULT nextval('tagihan_id_pengunaan_seq'::regclass);


--
-- Name: tagihan id_pelanggan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tagihan ALTER COLUMN id_pelanggan SET DEFAULT nextval('tagihan_id_pelanggan_seq'::regclass);


--
-- Name: tarif id_tarif; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tarif ALTER COLUMN id_tarif SET DEFAULT nextval('tarif_id_tarif_seq'::regclass);


--
-- Name: tb_admin id_admin; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_admin ALTER COLUMN id_admin SET DEFAULT nextval('tb_admin_id_admin_seq'::regclass);


--
-- Name: tb_level id_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level ALTER COLUMN id_level SET DEFAULT nextval('tb_level_id_level_seq'::regclass);


--
-- Data for Name: pelanggan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pelanggan (id_pelanggan, username, password, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM stdin;
\.
COPY pelanggan (id_pelanggan, username, password, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM '$$PATH$$/2865.dat';

--
-- Data for Name: pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM stdin;
\.
COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM '$$PATH$$/2873.dat';

--
-- Data for Name: penggunaan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM stdin;
\.
COPY penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM '$$PATH$$/2863.dat';

--
-- Data for Name: tagihan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tagihan (id_tagihan, id_pengunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM stdin;
\.
COPY tagihan (id_tagihan, id_pengunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM '$$PATH$$/2869.dat';

--
-- Data for Name: tarif; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tarif (id_tarif, daya, tarif_perkwh) FROM stdin;
\.
COPY tarif (id_tarif, daya, tarif_perkwh) FROM '$$PATH$$/2875.dat';

--
-- Data for Name: tb_admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_admin (id_admin, username, password, nama_admin, id_level) FROM stdin;
\.
COPY tb_admin (id_admin, username, password, nama_admin, id_level) FROM '$$PATH$$/2877.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2879.dat';

--
-- Name: pelanggan_id_pelanggan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pelanggan_id_pelanggan_seq', 1, false);


--
-- Name: pembayaran_id_pelanggan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pembayaran_id_pelanggan_seq', 1, false);


--
-- Name: pembayaran_id_pembayaran_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pembayaran_id_pembayaran_seq', 1, false);


--
-- Name: pembayaran_id_tagihan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pembayaran_id_tagihan_seq', 1, false);


--
-- Name: penggunaan_id_penggunaan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('penggunaan_id_penggunaan_seq', 1, false);


--
-- Name: tagihan_id_pelanggan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tagihan_id_pelanggan_seq', 1, false);


--
-- Name: tagihan_id_pengunaan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tagihan_id_pengunaan_seq', 1, false);


--
-- Name: tagihan_id_tagihan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tagihan_id_tagihan_seq', 1, false);


--
-- Name: tarif_id_tarif_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tarif_id_tarif_seq', 1, false);


--
-- Name: tb_admin_id_admin_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_admin_id_admin_seq', 1, false);


--
-- Name: tb_level_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_level_id_level_seq', 1, false);


--
-- Name: pelanggan pelanggan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pelanggan
    ADD CONSTRAINT pelanggan_pkey PRIMARY KEY (id_pelanggan);


--
-- Name: pembayaran pembayaran_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_pkey PRIMARY KEY (id_pembayaran);


--
-- Name: penggunaan penggunaan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY penggunaan
    ADD CONSTRAINT penggunaan_pkey PRIMARY KEY (id_penggunaan);


--
-- Name: tagihan tagihan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tagihan
    ADD CONSTRAINT tagihan_pkey PRIMARY KEY (id_tagihan);


--
-- Name: tarif tarif_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tarif
    ADD CONSTRAINT tarif_pkey PRIMARY KEY (id_tarif);


--
-- Name: tb_admin tb_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_admin
    ADD CONSTRAINT tb_admin_pkey PRIMARY KEY (id_admin);


--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- PostgreSQL database dump complete
--

